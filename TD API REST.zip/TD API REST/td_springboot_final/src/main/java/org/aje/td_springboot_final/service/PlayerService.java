package org.aje.td_springboot_final.service;

import java.util.List;

import org.aje.td_springboot_final.domain.Player;

public interface PlayerService {

	public List<Player> findAllPlayers();

	public Player findPlayer(Long id);

	public Player createPlayer(Player player);

	public void deletePlayer(Long id);

	public Player savePlayer(Player foundPlayer);
}
