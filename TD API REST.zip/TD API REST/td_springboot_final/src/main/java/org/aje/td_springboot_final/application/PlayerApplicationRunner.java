package org.aje.td_springboot_final.application;

import org.aje.td_springboot_final.dao.PlayerRepository;
import org.aje.td_springboot_final.domain.Player;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class PlayerApplicationRunner implements ApplicationRunner {

	@Autowired
	private PlayerRepository playerRepository;
	
	@Override
	public void run(ApplicationArguments args) throws Exception {
		
		Player wembanyama = new Player();
		wembanyama.setFirstName("Victor");
		wembanyama.setLastName("Wembanyama");
		wembanyama.setAge("20");
		wembanyama.setNationality("French");
		this.playerRepository.save(wembanyama);
		
		Player doncic = new Player();
		doncic.setFirstName("Luka");
		doncic.setLastName("Doncic");
		doncic.setAge("24");
		doncic.setNationality("Slovenian");
		this.playerRepository.save(doncic);
		
		Player embiid = new Player();
		embiid.setFirstName("Joel");
		embiid.setLastName("Embiid");
		embiid.setAge("29");
		embiid.setNationality("Cameroonian");
		this.playerRepository.save(embiid);
	}

}
