package org.aje.td_springboot_final.application;

import org.aje.td_springboot_final.dao.TeamRepository;
import org.aje.td_springboot_final.domain.Team;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class TeamApplicationRunner implements ApplicationRunner {

	@Autowired
	private TeamRepository teamRepository;
	
	@Override
	public void run(ApplicationArguments args) throws Exception {
		
		Team spurs = new Team();
		spurs.setName("San Antonio Spurs");
		spurs.setCity("San Antonio");
		this.teamRepository.save(spurs);
		
		Team clippers = new Team();
		clippers.setName("Los Angeles Clippers");
		clippers.setCity("Los Angeles");
		this.teamRepository.save(clippers);
		
		Team pistons = new Team();
		pistons.setName("Detroit Pistons");
		pistons.setCity("Detro");
		this.teamRepository.save(pistons);
	}

}
