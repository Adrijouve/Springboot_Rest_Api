package org.aje.td_springboot_final.dao;

import org.aje.td_springboot_final.domain.Player;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlayerRepository extends JpaRepository<Player, Long> {

}
