package org.aje.td_springboot_final.dao;

import org.aje.td_springboot_final.domain.Team;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeamRepository extends JpaRepository<Team, Long> {

}
