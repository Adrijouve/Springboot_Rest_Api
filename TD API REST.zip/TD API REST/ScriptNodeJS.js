const axios = require('axios');


/******** Test on Team Entity *********/
const apiURL = 'http://localhost:8080/teams';

//Get all team
axios.get(apiURL)
    .then(response => {
        console.log('All team : \n', response.data);
    })
    .catch(error => {
        console.error('API Error : \n', error.message);
    })

const apiURL2 = "http://localhost:8080/teams/4";

//Get only one team from the list
axios.get(apiURL2)
    .then(response => {
        console.log('Team with ID 4 : \n', response.data);
    })
    .catch(error => {
        console.error('API Error : \n', error.message);
    })


//Delete a team from the list
axios.delete(apiURL2)
    .then(response => {
        console.log("Deletion successful");
    })
    .catch(error => {
        console.error('API Error : \n', error.message);
    })

const postData = {
    "name": "Phoenix Suns",
    "city": "Phoenix"
}

axios.post(apiURL, postData)
    .then(response => {
        console.log("Team added : \n", response.data);
    })
    .catch(error => {
        console.error('API Error : \n', error.message);
    })


const apiURLput = "http://localhost:8080/teams/6"

const putData = {
    "name": "Detroit Pistons",
    "city": "Detroit"
}

axios.put(apiURLput, putData)
    .then (response => {
        console.log("Team modified : \n", response.data);
    })
    .catch(error => {
        console.error('API Error : \n', error.message);
    })


/********* Test on Player entity *********/

postPlayer = {
    "firstName": "Rudy",
    "lastName": "Gobert",
    "age": "31",
    "nationality": "French"
}

putPlayer = {
    "firstName": "Joel",
    "lastName": "Embiid",
    "age": "31",
    "nationality": "American"
}

const apiURLplayer = "http://localhost:8080/players";
const apiURLplayer2 = "http://localhost:8080/players/1";
const apiURLplayerPut = "http://localhost:8080/players/3";

axios.get(apiURLplayer)
    .then(response => {
        console.log('All players : \n', response.data);
    })
    .catch(error => {
        console.error('API Error : \n', error.message);
    })
    .then(() =>{
        axios.delete(apiURLplayer2)
            .then(response => {
                console.log('Deletion successful', response.data);
            })
            .catch(error => {
                console.error("API Error : \n", error.message);
            })
    })
    .then(() => {
        axios.put(apiURLplayerPut, putPlayer)
            .then(response => {
                console.log('Player modified : \n', response.data)
            })
            .catch(error => {
                console.error('API Error : \n', error.message);
            })
    })

axios.post(apiURLplayer, postPlayer)
    .then(response => {
        console.log('New Player : \n', response.data);
    })
    .catch(error => {
        console.error('API Error : \n', error.message);
    })